
function clickEvent() {
  alert('ボタンをクリック');
}