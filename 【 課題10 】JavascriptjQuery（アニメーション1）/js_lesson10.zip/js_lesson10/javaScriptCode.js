
function clickTest() {
  target = document.getElementById("anime_test");

    target.className = "active";

}