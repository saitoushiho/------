<?php
//この問題はカリキュラムの進捗に余裕があり、論理思考を鍛えたい人向けの発展問題です。

//【解答必須ではないので、algorithm01~04の解答が完了したら一度提出し、発展問題に取り組むかどうかは講師と相談してください。】

//EX.以下の整理されていない配列$inを$outのように整形して出力してください

$in = [
    ['2nd' => 'two', 'four' => '4th'],
    'three' => '3rd',
    ['one' => '1st'],
    '10th' => 'ten',
    ['6th' => 'six'],
    '5th' => 'five',
    'seven' => '7th',
    ['fourteen' => '14th', '11th' => 'eleven'],
    ['8th' => 'eight'],
    'thirteen' => '13th',
    '12th' => 'twelve',
    'nine' => '9th',
    ['15th' => 'fifteen'],
];

// $out = [
//     '1st' => 'one',
//     '2nd' => 'two',
//     '3rd' => 'three',
//     '4th' => 'four',
//     '5th' => 'five',
//     '6th' => 'six',
//     '7th' => 'seven',
//     '8th' => 'eight',
//     '9th' => 'nine',
//     '10th' => 'ten',
//     '11th' => 'eleven',
//     '12th' => 'twelve',
//     '13th' => 'thirteen',
//     '14th' => 'fourteen',
//     '15th' => 'fifteen',
// ];
