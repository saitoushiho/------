
function onDisplay() {
  alert(document.getElementById("textBox").value);
}