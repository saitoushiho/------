﻿<?php

    // 配列$colorsにred,blue,yellowを格納し、
    // blueを出力してください。

    //配列に文字を格納
    $colorArray = ['red', 'blue', 'yellow'];

    //出力
    echo $colorArray[1];

?>