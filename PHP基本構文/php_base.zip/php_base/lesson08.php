﻿<?php

    // 引数として数値を渡すと+1して返す関数を作り、
    // 返り値を出力してください。

    //関数
    function plusOne($argNum){
        echo $argNum+1;
    }

    //+1する関数を呼び出す
    plusOne(1233);

?>
