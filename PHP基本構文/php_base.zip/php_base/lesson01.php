﻿<?php
    // 「Hello world.」という文字列を
    // 変数に代入して出力してください。

    // 変数に文字を入力する
    $stringWord = 'Hello world.';

    // 文字を表示する
    echo $stringWord;

?>
